//
//  main.m
//  Encryption
//
//  Created by jianyi.chen on 2019/8/31.
//  Copyright © 2019 IN3. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
